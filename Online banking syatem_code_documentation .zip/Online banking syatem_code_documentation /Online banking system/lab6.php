<head>
<title>table</title>
</head>
<body>
<table border="1px" align="center" width="1350" cellspacing="1x">
<tr align="center" bgcolor="LawnGreen " height="250px"><td colspan=2><big><font size="10">Online Banking System</font></big></td></tr> 
<tr height="300px" bgcolor="PaleTurquoise "><td colspan=2>
<div align="center"><b><font size="6">Click one of options below</font></b></br><br>
<a href="lab6_part2.php">1.Create a new account.</br></a><br>
<a href="lab6_part3.php">2.Make Transaction.</br></a><br>
<a href="lab6_part4.php">3.View Account details.</br></a><br>

</td></tr>
<tr bgcolor="LawnGreen " height="50px"><td colspan=6></td></tr>
</table>
</body>
</html>

<?php

$dbhost = 'localhost';$dbuser='root';$dbpass='123456789';
$conn=mysql_connect($dbhost,$dbuser,$dbpass);
mysql_select_db("nasir_ansari");
if(! $conn) {
 die( 'Unable to select database');            
             }
if (@$_POST["Create"] <> ""){
  $CustomerId = $_POST['CustomerId'];
  $AccountNumber = $_POST['AccountNumber'];
  $Password = $_POST['Password'];
  $AccountType =$_POST['AccountType']; 
                             }
$query = mysql_query("INSERT INTO Accounts VALUES('$CustomerId','$AccountNumber','$Password','$AccountType')") ;
else if(@$_POST["summit"] <> ""))
	{
$AccountNumber = $_POST['AccountNumber'];
$Password = $_POST['Password'];
$result = mysql_query(('SELECT * FROM Accounts WHERE AccountNumber = '$AccountNumber')');
           }

mysql_close($conn);
?>

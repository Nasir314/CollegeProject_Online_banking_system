<head>
<title>table</title>
</head>
<body>
<table border="1px" align="center" width="1350" cellspacing="1x">
<tr align="center" bgcolor="LawnGreen " height="250px"><td colspan=2><big><font size="10">Online Banking System</font></big></td></tr> 
<tr height="300px" bgcolor="PaleTurquoise "><td colspan=2>
<div align="center">
<?php
$username="root";$password="123456789";$database="nasir_ansari";
$conn = mysql_connect(localhost,$username,$password);
mysql_select_db($database) or die( "Unable to select database");

if (@$_POST["submit"] <> "") {
	$from_number = $_POST['from_number'];
	$to_number = $_POST['to_number'];
	$amount = $_POST['amount'];

	$query = "select bal from account where acc_no=('$from_number')";
	$retval = mysql_query($query);
	if(!$retval)
	{
		die('Could not get data:');
	}
	$row = mysql_fetch_array($retval);
	$bal1=$row['bal'];
	//echo $bal;
	$query = "select bal from account where acc_no=('$to_number')";
	$retval = mysql_query($query);
	if(!$retval)
	{
		die('Could not get data:');
	}
	$row = mysql_fetch_array($retval);
	$bal2=$row['bal'];
	if($amount>$bal1)
	{
		echo "Amount entered is more than Account balance so this can not possible";
	}
	else
	{
		$query=mysql_query("update account set bal=$bal1-$amount where acc_no=('$from_number')");
		$query=mysql_query("update account set bal=$bal2+$amount where acc_no=('$to_number')");
		echo "Transaction done successfully";
	}
}
mysql_close($conn);
?>
<br><br>
<b><a href="lab6.php">Back To Home page</a></b>
</td></tr>
<tr bgcolor="LawnGreen " height="50px"><td colspan=6></td></tr>
</table>
</div>
</body>
</html>


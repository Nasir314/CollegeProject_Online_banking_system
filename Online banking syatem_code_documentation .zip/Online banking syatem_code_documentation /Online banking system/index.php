<html>
<head>
<title>course Registration</title>
</head>





<body>

  <table ><tr><td><b>COURSE REGISTRATION</b></td></tr></table>
<table  >
<tr>
<form action="login.php" method="Post" >
 <p  ><input type="text" name= "name"  placeholder="First Name"> </p>
 <p ><input  type="text" name= "rollnumber" maxlength="6" placeholder="Roll Number">  </p>
 <p> <input type="text" name= "add" placeholder="ADDRESS"> </p>
 <p><input  type="text" name= "dept" maxlength="10" placeholder="DEPT"> </p>
 <p> <input type="submit" name= "submit" value="Submit"> </p>
</form>
</tr>
</table>

</body>

</html>

<?php
if(isset($_POST['submit']))
{
  $name = mysql_real_escape_string($_POST['name']);
  $rollnumber = mysql_real_escape_string($_POST['rollnumber']);
  $add = mysql_real_escape_string($_POST['add']);
  $dept = mysql_real_escape_string($_POST['dept']);
}
?>









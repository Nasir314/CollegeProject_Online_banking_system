<head>
<title>table</title>
</head>
<body>
<table border="1px" align="center" width="1350" cellspacing="1x">
<tr align="center" bgcolor="LawnGreen " height="250px"><td colspan=2><big><font size="10">Online Banking System</font></big></td></tr> 
<tr height="300px" bgcolor="PaleTurquoise "><td colspan=2>
<div align="center">
<?php
$username="root";$password="123456789";$database="nasir_ansari";
$conn = mysql_connect(localhost,$username,$password);
mysql_select_db($database) or die( "Unable to select database");

if (@$_POST["submit"] <> "")
{$acc_no = $_POST['acc_no'];}
$query= "select * from account where acc_no=('$acc_no')";
$retval = mysql_query($query);
if(!$retval)
   {
      die('You have no information for this account number');
   }

   while($row = mysql_fetch_array($retval))
   {
      echo "-------------------------------------------WELCOME YOUR ACCOUNT---------------------------------------------<br><br>". 
         "<b>   ACCOUNT NO:     </b>{$row['acc_no']}  <br> <br>".
         "<b>   CUSTOMER ID:    </b> {$row['Cust_id']} <br> <br> ".
        "<b>    BALANCE:        </b> {$row['bal']} <br><br> ".
        "<b>    ACCOUNT TYPE:   </b> {$row['acc_type']} <br><br> ".
         "-----------------------------------------------------BYE---------------------------------------------------------<br>";
   }

mysql_close($conn); 
?>
<br><br>
<b><a href="lab6.php">Back To Home page</a></b>
</td></tr>
<tr bgcolor="LawnGreen " height="50px"><td colspan=6>
</td></tr>
</table>
</div>
</body>
</html>

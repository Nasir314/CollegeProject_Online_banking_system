<html>
<head>
<title>table</title>
</head>
<body>
<table border="5px" align="center" width="1000px" cellspacing="2px">
<tr align="center" bgcolor="pink" height="100px"><td colspan=6><big>BANKING SYSTEM</big></td></tr>
<tr height="300px" bgcolor="yellow"><td colspan=6>
<div align="center"><b>Click one of options below</b></br>
<a href="lab6_part2.php">1.Create a new account.</br></a>
<a href="lab6_part3.php">2.Make Transaction.</br></a>
<a href="lab6_part4.php">3.View Account details.</br></a>

</td></tr>
<tr bgcolor="green" height="50px"><td colspan=6></td></tr>
</table>
</body>
</html>

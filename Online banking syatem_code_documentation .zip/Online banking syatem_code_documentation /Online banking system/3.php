<?php
//Step1
 $db = mysql_connect("localhost","root","123456789"); 
 if (!$db) {
 die("Database connection failed miserably: " . mysql_error());
 }
//Step2
 $db_select = mysql_select_db("nasir_ansari",$db);
 if (!$db_select) {
 die("Database selection also failed miserably: " . mysql_error());
 }
?>
<html>
 <head>
 <title>Step 5</title>
 </head>
 <body>
<div class="cssstyle">
 <?php
//Step3
$result = mysql_query("SELECT * FROM Bookings", $db);
 if (!$result) {
 die("Database query failed: " . mysql_error());
 }
//Step4
 while ($row = mysql_fetch_array($result)) {
 echo "<h2>";
 echo $row[1]."";
 echo "</h2>";
 echo "<p>";
 echo $row[2]."";
 echo "</p>";
 }
?>
</div>
 </body>
</html>
 
<?php
//Step5
 mysql_close($db);
?>

